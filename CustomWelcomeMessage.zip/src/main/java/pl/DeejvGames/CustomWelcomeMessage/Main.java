package pl.DeejvGames.CustomWelcomeMessage;

import org.bukkit.plugin.java.JavaPlugin;
import pl.DeejvGames.CustomWelcomeMessage.events.playerJoin;
import pl.DeejvGames.CustomWelcomeMessage.events.playerQuit;
import pl.DeejvGames.CustomWelcomeMessage.other.UpdateChecker;

public final class Main extends JavaPlugin {

    @Override
    public void onEnable() {
        if(getConfig().getBoolean("check-updates")){
            new UpdateChecker(120213).getVersion(version -> {
                if(getDescription().getVersion().equals(version)) {
                    getLogger().info("You are using the latest version!");
                } else {
                    getLogger().info("There is new update available!");
                    getLogger().info("Current version: "+getDescription().getVersion());
                    getLogger().info("Latest version: "+version);
                }
            }
            );
        }
        getServer().getPluginManager().registerEvents(new playerJoin(), this);
        getServer().getPluginManager().registerEvents(new playerQuit(), this);
        getCommand("cwm").setExecutor(new cwmCommands());
        getConfig().options().copyDefaults(true);
        saveDefaultConfig();
        getLogger().info("Plugin Enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("Plugin Disabled!");
    }
}
