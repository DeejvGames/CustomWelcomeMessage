package pl.DeejvGames.CustomWelcomeMessage;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import pl.DeejvGames.CustomWelcomeMessage.other.ChatSender;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class cwmCommands implements CommandExecutor, TabCompleter {
    Main plugin = Main.getPlugin(Main.class);

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args){
        if(!(sender.hasPermission("cwm.usage"))){
            ChatSender.fullMessageSender(sender, plugin.getConfig().getString("no-permission"));
            return true;
        }
        if(args.length != 1){
            ChatSender.fullMessageSender(sender, plugin.getConfig().getString("command-usage"));
            return true;
        }
        if(!(args[0].equalsIgnoreCase("info") || args[0].equalsIgnoreCase("reload"))){
            ChatSender.fullMessageSender(sender, plugin.getConfig().getString("command-usage"));
            return true;
        }
        if(args[0].equalsIgnoreCase("reload")){
            plugin.reloadConfig();
            ChatSender.fullMessageSender(sender, plugin.getConfig().getString("plugin-reloaded"));
            return true;
        }
        if(args[0].equalsIgnoreCase("info")){
            ChatSender.fullMessageSender(sender, " ");
            ChatSender.fullMessageSender(sender, "&x&f&f&a&a&6&9&lCustomWelcomeMessage");
            ChatSender.fullMessageSender(sender, " ");
            ChatSender.fullMessageSender(sender, "&6Author: &eDeejvGames");
            ChatSender.fullMessageSender(sender, "&6Version: &e"+plugin.getDescription().getVersion());
            ChatSender.fullMessageSender(sender, "&6Commands: &e/cwm info&6, &e/cwm reload");
            ChatSender.fullMessageSender(sender, " ");
            return true;
        }
        return false;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> completions = new ArrayList<>();
        if(cmd.getName().equalsIgnoreCase("cwm")) {
            if(args.length == 1) {
                List<String> subCommands = Arrays.asList("info", "reload");
                for(String subCommand : subCommands) {
                    if(subCommand.toLowerCase().startsWith(args[0].toLowerCase())) {
                        completions.add(subCommand);
                    }
                }
            }
        }
        return completions;
    }
}
