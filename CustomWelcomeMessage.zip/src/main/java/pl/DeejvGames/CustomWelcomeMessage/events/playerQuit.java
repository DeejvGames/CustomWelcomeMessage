package pl.DeejvGames.CustomWelcomeMessage.events;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import pl.DeejvGames.CustomWelcomeMessage.Main;

public class playerQuit implements Listener {
    Main plugin = Main.getPlugin(Main.class);

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event){
        Player player = event.getPlayer();
        String leaveMessage = plugin.getConfig().getString("global-leave-message").replace("{PLAYER}", player.getName()).replace("{ONLINE}", Integer.toString(Bukkit.getOnlinePlayers().size())).replace("{UNIQUE_PLAYERS}", String.valueOf(plugin.getServer().getOfflinePlayers().length));
        String finalMessage = null;
        ConfigurationSection premiumLeaveMessageSection = plugin.getConfig().getConfigurationSection("premium-leave-message-list");
        if(plugin.getConfig().getBoolean("premium-leave-message")){
            if(premiumLeaveMessageSection != null){
                for(String permission : premiumLeaveMessageSection.getKeys(false)){
                    String message = premiumLeaveMessageSection.getString(permission);

                    if(player.isPermissionSet(permission)){
                        finalMessage = message.replace("{PLAYER}", player.getName()).replace("{ONLINE}", Integer.toString(Bukkit.getOnlinePlayers().size())).replace("{UNIQUE_PLAYERS}", String.valueOf(plugin.getServer().getOfflinePlayers().length));
                    }
                }
            }
        }
        event.setQuitMessage(null);
        if(plugin.getConfig().getBoolean("premium-leave-message")){
            if(finalMessage != null){
                Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', finalMessage));
            } else{
                Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', leaveMessage));
            }
        } else{
            Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', leaveMessage));
        }
    }
}
