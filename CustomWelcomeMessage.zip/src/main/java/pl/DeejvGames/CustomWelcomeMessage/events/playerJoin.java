package pl.DeejvGames.CustomWelcomeMessage.events;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import pl.DeejvGames.CustomWelcomeMessage.Main;
import pl.DeejvGames.CustomWelcomeMessage.other.ChatSender;

public class playerJoin implements Listener {
    Main plugin = Main.getPlugin(Main.class);

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event){
        Player player = event.getPlayer();
        String joinMessage = plugin.getConfig().getString("global-join-message").replace("{PLAYER}", player.getName()).replace("{ONLINE}", Integer.toString(Bukkit.getOnlinePlayers().size())).replace("{UNIQUE_PLAYERS}", String.valueOf(plugin.getServer().getOfflinePlayers().length));
        String uniqueJoinMessage = plugin.getConfig().getString("unique-player-join-message").replace("{PLAYER}", player.getName()).replace("{ONLINE}", Integer.toString(Bukkit.getOnlinePlayers().size())).replace("{UNIQUE_PLAYERS}", String.valueOf(plugin.getServer().getOfflinePlayers().length));
        String finalMessage = null;
        ConfigurationSection premiumJoinMessageSection = plugin.getConfig().getConfigurationSection("premium-join-message-list");
        if(plugin.getConfig().getBoolean("premium-join-message")) {
            if(premiumJoinMessageSection != null) {
                for(String permission : premiumJoinMessageSection.getKeys(false)) {
                    String message = premiumJoinMessageSection.getString(permission);
//                Bukkit.getLogger().info("[DEBUG] Read message: " + message); // DEBUG
                    if(player.isPermissionSet(permission)) {
//                        Bukkit.getLogger().info("[DEBUG] Read permission: "+ permission); // DEBUG
                        finalMessage = message.replace("{PLAYER}", player.getName()).replace("{ONLINE}", Integer.toString(Bukkit.getOnlinePlayers().size())).replace("{UNIQUE_PLAYERS}", String.valueOf(plugin.getServer().getOfflinePlayers().length));
                    }
                }
            }
        }
        event.setJoinMessage(null);
        if(plugin.getConfig().getBoolean("unique-player-join")){
            if(!player.hasPlayedBefore()){
                Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', uniqueJoinMessage));
            } else{
                joinAction(finalMessage, joinMessage);
            }
        } else{
            joinAction(finalMessage, joinMessage);
        }
        if(plugin.getConfig().getBoolean("personal-clear-chat")){
            for(int i = 0; i<plugin.getConfig().getInt("clear-chat-lines-amount"); i++){
                ChatSender.fullMessage(player, " ");
            }
        }
        if(plugin.getConfig().getBoolean("personal-join-message-setting")) {
            String personalJoinMessage = plugin.getConfig().getString("personal-join-message").replace("{PLAYER}", player.getName()).replace("{ONLINE}", Integer.toString(Bukkit.getOnlinePlayers().size())).replace("{UNIQUE_PLAYERS}", String.valueOf(plugin.getServer().getOfflinePlayers().length));
            ChatSender.fullMessage(player, personalJoinMessage);
        }
        if(plugin.getConfig().getBoolean("personal-join-playsound")){
            player.playSound(player.getLocation(), Sound.valueOf(plugin.getConfig().getString("personal-join-sound")), ((float) plugin.getConfig().getDouble("personal-join-sound-volume")), ((float) plugin.getConfig().getDouble("personal-join-sound-pitch")));
        }
        if(plugin.getConfig().getBoolean("personal-join-show-title")){
            showTitle(player);
        }
    }

    public void joinAction(String finalMessage, String joinMessage){
        if(plugin.getConfig().getBoolean("premium-join-message")){
            if(finalMessage != null){
                Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', finalMessage));
            } else{
                Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', joinMessage));
            }
        } else{
            Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', joinMessage));
        }
    }

    public void showTitle(Player player){
        String title = plugin.getConfig().getString("personal-join-title").replace("{PLAYER}", player.getName()).replace("{ONLINE}", Integer.toString(Bukkit.getOnlinePlayers().size())).replace("{UNIQUE_PLAYERS}", String.valueOf(plugin.getServer().getOfflinePlayers().length));
        String subtitle = plugin.getConfig().getString("personal-join-subtitle").replace("{PLAYER}", player.getName()).replace("{ONLINE}", Integer.toString(Bukkit.getOnlinePlayers().size())).replace("{UNIQUE_PLAYERS}", String.valueOf(plugin.getServer().getOfflinePlayers().length));
        player.sendTitle(ChatColor.translateAlternateColorCodes('&', title), ChatColor.translateAlternateColorCodes('&', subtitle), plugin.getConfig().getInt("personal-join-title-fadein"), plugin.getConfig().getInt("personal-join-title-stay"),plugin.getConfig().getInt("personal-join-title-fadeout"));
    }
}
